package com.keycloak.project;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.saml2.provider.service.authentication.Saml2AuthenticatedPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import javax.annotation.security.RolesAllowed;

@RestController
public class SecuityController {


    @GetMapping("/user/hello")
    public String getHelloMessage() {
        return "Hello user";
    }


    @GetMapping("/admin/hello")
    public String getByeMessage() {
    return "Hello Admin";
    }

    @GetMapping("/public/hello")
    public String getHello() {
        return "Hello All";
    }

    @RequestMapping("/secured/hello")
    public String hello(@AuthenticationPrincipal Saml2AuthenticatedPrincipal principal) {

        return "hello";
    }
}
